<?php
$languageStrings = [ 
	'LBL_SALES_PROCESSES' => 'תהליכי מכירות',
	'LBL_SALES_PROCESSES_DESCRIPTION' => '',
	'LBL_LIMIT_PRODUCT_AND_SERVICE' => 'מאפשר לבחור מרשימת מוצרים רק אלה הקשורים לנבחרו oportunity. סיפק ל: חישובים, הצעות מחיר, הזמנות ומכירות חשבוניות.',
	'LBL_PRODUCTS_AND_SERVICES_POPUP' => 'מוצרים ושירותי רשימת בחירה',
	'LBL_UPDATE_SHARED_PERMISSIONS' => 'עדכוני שיתוף הרשאות ממוצר / שירות בהזדמנות כאשר יחס בין ההזדמנות ומוצר / שירות נוצר.',
	'LBL_CALCULATIONS' => 'חישובים',
	'LBL_STATUSES_CLOSED_CALCULATION' => 'סטטוסים קביעת החישוב שנסגרו',
	'LBL_POTENTIALS' => 'הזדמנויות',
	'LBL_STATUSES_CLOSED_POTENTIAL' => 'סטטוסים קביעת ההזדמנות שנסגרו',
	'LBL_ASSETS' => 'מוצרים נמכרים',
	'LBL_STATUSES_CLOSED_ASSETS' => 'סטטוסים קביעת שהמוצר נמכר סגור',
	'LBL_CREATE_POTENTIALS' => 'חסימת יצירת ההזדמנויות לחשבונות / ארגונים שבהוקצו לאינה משתמש',
];
$jsLanguageStrings = [
];