<?php
$languageStrings = [ 
	'LBL_CONVERSION' => 'המרה',
	'LBL_CONVERSION_TO_ACCOUNT' => 'לשנות מוקצה ל',
	'LBL_CONVERSION_TO_ACCOUNT_INFO' => 'כאשר אפשרות זו מסומנת, משתמש שממיר ליד לחשבון הופך מוקצה ל',
	'LBL_LEADS' => 'לידים',
	'LBL_INFO' => 'מידע',
	'LBL_VALUES' => 'ערכים',
	'LBL_GROUPS_INFO' => 'קבוצות ללא מוקצה ל',
	'LBL_LEAD_STATUS' => 'סטטוסים המצביעים על סוף העבודה עם לידים',
	'LBL_CURRENTUSER_STATUS' => 'לשנות מוקצה למשתמש שעורך שיא',
];
$jsLanguageStrings = [
];