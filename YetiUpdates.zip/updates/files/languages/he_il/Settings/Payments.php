<?php
$languageStrings = [ 
	'Payments' => 'תשלומים',
	'LBL_RIGHT_CLICK_COPY' => 'לחץ לחיצה ימנית ולהעתיק',
];
$jsLanguageStrings = [
	'JS_DELETED_SUCCESSFULLY' => 'נמחק בהצלחה',
	'JS_SAVED_SUCCESSFULLY' => 'נשמר בהצלחה',
];