<?php
$languageStrings = [ 
	'Document Control' => 'מסמך בקרה',
	'OSSDocumentControl' => 'מסמך בקרה',
	'LBL_ENTER_BASIC_INFO' => 'הזן את המידע הבסיסי',
	'LBL_STEP_1' => 'שלב 1',
	'NEXT' => 'הבא',
	'CANCEL' => 'לבטל',
];
$jsLanguageStrings = [
	'Document Control' => 'מסמך בקרה',
	'OSSDocumentControl' => 'מסמך בקרה',
	'DES_REQUIRED' => 'תיאור של המסמך נדרש',
	'DES_NAME_REQUIRED' => 'שם המסמך נדרש',
];