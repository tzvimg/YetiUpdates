<?php
$languageStrings = [ 
	'LBL_SELECT_ONE' => 'בחר',
	'LBL_PBXMANAGER' => 'PBXManager',
	'LBL_PBXMANAGER_CONFIG' => 'פרטי שרת אסטריסק',
	'LBL_NOTE' => 'הערה:',
	'LBL_INFO_WEBAPP_URL' => 'קביעת תצורה של כתובת אתר אסטריסק App שלך בפורמט',
	'LBL_FORMAT_WEBAPP_URL' => '(פרוטוקול): // (asterisk_ip): (VtigerConnector_port)',
	'LBL_FORMAT_INFO_WEBAPP_URL' => 'לשעבר: http: //0.0.0.0: 5000',
	'LBL_INFO_CONTEXT' => 'YetiForce הקשר specfic המוגדר בשרת אסטריסק שלך (extensions.conf)',
	'LBL_PBXMANAGER_INFO' => 'קביעת תצורה של אסטריסק שרת פרטים לאחר התקנת YetiForce אסטריסק מחבר בשרת אסטריסק שלך',
	'webappurl' => 'כתובת אתר YetiForce אסטריסק App',
	'vtigersecretkey' => 'YetiForce מפתח סודי',
	'outboundcontext' => 'הקשר יוצא',
	'outboundtrunk' => 'יוצא Trunk',
];
$jsLanguageStrings = [
];