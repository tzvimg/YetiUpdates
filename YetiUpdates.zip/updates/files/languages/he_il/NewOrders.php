<?php
$languageStrings = [ 
	'NewOrders' => 'הזמנות חדשות',
	'SINGLE_NewOrders' => 'הזמנות חדשות',
	'LBL_NEWORDERS_INFORMATION' => 'מידע בסיסי',
	'LBL_SUBJECT' => 'נושא',
];
$jsLanguageStrings = [
];