<?php
$languageStrings = [ 
	'LBL_ADD_RECORD' => 'הוסף רשומה',
	'LBL_ADD_TO' => 'להוסיף ל',
	'LBL_EDIT_LIST_PRICE' => 'ערוך רשימת מחיר',
	'LBL_PRICEBOOK_INFORMATION' => 'מחיר ספר פרטים',
	'LBL_RECORDS_LIST' => 'מחיר ספרי רשימה',
	'LBL_UNIT_PRICE' => 'מחיר ליחידה',
	'Price Book Name' => 'מחיר הספר שם',
	'PriceBook No' => 'מחיר ספר מספר',
	'PriceBooks' => 'ספרי מחיר',
	'SINGLE_PriceBooks' => 'מחיר הספר',
];
$jsLanguageStrings = [
];