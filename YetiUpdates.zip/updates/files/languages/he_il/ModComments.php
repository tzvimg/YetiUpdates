<?php
$languageStrings = [ 
	'SINGLE_ModComments' => 'הערה',
	'LBL_RECORDS_LIST' => 'רשימת הערות',
	'LBL_MODCOMMENTS_INFORMATION' => 'הערות',
	'LBL_OTHER_INFORMATION' => 'מידע אחר',
	'LBL_ADDING_COMMENT' => 'הוסף הערה',
	'LBL_WRITE_YOUR_COMMENT_HERE' => 'הזן הערות כאן',
	'Comment' => 'הערה',
	'Creator' => 'יוצר',
	'Related To Comments' => 'קשור ל',
];
$jsLanguageStrings = [
];