<?php
$languageStrings = [ 
	'OSSOutsourcedServices' => 'שירותי מיקור חוץ',
	'SINGLE_OSSOutsourcedServices' => 'שירות במיקור חוץ',
	'LBL_INFORMATION' => 'מידע בלוק',
	'Assigned To' => 'שהוקצה ל',
	'LBL_osservicesstatus' => 'סטטוס',
	'Individual Agreement' => 'הסכם אישי',
	'In service' => 'נתמך',
	'Finished support' => 'תמיכה הופסקה',
	'Product Name' => 'שם שירות',
	'Sub Category' => 'תת קטגוריה',
	'Category' => 'קטגוריה',
	'Date Sold' => 'תאריך המכירה',
	'Date in Service' => 'תאריך סיום תמיכה',
	'Description' => 'תיאור',
	'LBL_DESCRIPTION_INFORMATION' => 'מידע תיאורים',
	'LBL_CUSTOM_INFORMATION' => 'מידע מערכת',
	'Where bought' => 'איפה קנה',
	'Number' => 'מספר',
	'Save' => 'שמור',
	'Selling proposition' => 'הזדמנות',
	'LBL_GENERATE_EXTENSION' => 'צור הארכה',
	'Active' => 'פעיל',
	'Inactive' => 'לא פעיל',
];
$jsLanguageStrings = [
];