<?php
$languageStrings = [ 
	'providertype' => 'ספק',
	'LBL_SMS_MAX_CHARACTERS_ALLOWED' => 'דמויות 160 מקסימום SMS מותר',
	'LBL_SEREVER_CONFIG' => 'תצורה חדשה',
	'username' => 'שם משתמש',
	'password' => 'סיסמא',
	'isactive' => 'פעיל',
	'LBL_SEND_SMS_TO_SELECTED_NUMBERS' => 'שלח SMS למספרים הנבחרים',
	'LBL_STEP_1' => 'שלב 1',
	'LBL_STEP_2' => 'שלב 2',
	'LBL_SELECT_THE_PHONE_NUMBER_FIELDS_TO_SEND' => 'בחר את שדות מספר הטלפון כדי לשלוח',
	'LBL_TYPE_THE_MESSAGE' => 'הקלד את ההודעה',
	'LBL_WRITE_YOUR_MESSAGE_HERE' => 'לכתוב את ההודעה שלך כאן',
	'LBL_ADD_MORE_FIELDS' => 'הוסף עוד שדות',
	'LBL_SERVER_CONFIG' => 'תצורת שרת',
	'LBL_CHECK_STATUS' => 'בדוק סטטוס',
	'message' => 'הודעה',
	'LBL_SMSNOTIFIER_INFORMATION' => 'מידע SMS',
	'SINGLE_SMSNotifier' => 'SMS Notifier',
		// From Number Field.
	'LBL_STEP_0' => 'שלב 0',
	'LBL_TYPE_THE_SRC_NUMBER' => 'הזן את המספר השולח. במקרה שלא יוזן מספר שולח, הסמס ישלח עם מספר ברירת המחדל<br> שהוגדר במערכת.',
	'LBL_SMS_SRC_MAX_CHARACTERS_ALLOWED' => 'מקסימום 11 תווים',
	'SMS_SRC_NUMBER' => 'המספר השולח',
];
$jsLanguageStrings = [
];