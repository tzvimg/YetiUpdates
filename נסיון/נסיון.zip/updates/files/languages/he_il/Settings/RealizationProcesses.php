<?php
$languageStrings = [ 
	'LBL_PROJECT_CONFIGURATION' => 'פרויקט',
	'LBL_INFO' => 'מידע',
	'LBL_TYPE' => 'סטטוס',
	'LBL_PROJECT' => 'פרויקט',
	'LBL_PROJECT_STATUS_INFO' => 'סטטוסים קביעה שהפרויקט סגור',
	'LBL_SAVE_CONFIG_OK' => 'שינויים נשמרו בהצלחה.',
	'LBL_SAVE_CONFIG_ERROR' => 'נכשל ניסיון לשמור את השינויים.',
];
$jsLanguageStrings = [
];