<?php
$languageStrings = [ 
	'QuickCreateEditor' => 'עריכת יצירה מהירה',
	'LBL_QUICK_CREATE_EDITOR' => 'עריכת יצירה מהירה',
	'LBL_QUICK_CREATE_EDITOR_DESCRIPTION' => 'מודול המאפשר לשנות את הפריסה של שדות בתוך quickcreate חלון',
	'LBL_SEQUENCE' => 'רצף שדה',
	'LBL_SAVE_FIELD_SEQUENCE' => 'שמור שדה רצף',
];
$jsLanguageStrings = [
	'JS_FIELD_SEQUENCE_UPDATED' => 'רצף שדה עדכון',
];