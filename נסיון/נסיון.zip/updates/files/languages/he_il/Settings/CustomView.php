<?php
$languageStrings = [ 
	'CustomView' => 'צפיות מותאמות אישית',
	'LBL_MODULE_DESC' => 'כלי זה מאפשר הגדרת תצוגות מותאמות אישית עבור מודולים. מודולים אלה חייבים לכלול רשומות ולהשתמש במסננים סטנדרטיים בYetiForce CRM.',
	'Module' => 'מודול',
	'ViewName' => 'צפה שם',
	'SetDefault' => 'ברירת מחדל',
	'Privileges' => 'הרשאות',
	'Delete' => 'מחק',
	'Delete CustomView' => 'תצוגה מותאמת אישית נמחקה',
	'Saving CustomView' => 'צפה בנשמר',
	'Actions' => 'פעולות',
	'Edit' => 'עריכה',
];
$jsLanguageStrings = [
	'Saving changes' => 'לשמור את השינויים ...',
	'Update labels' => 'עדכון',
];