<?php
$languageStrings = [ 
	'Ideas' => 'רעיונות',
	'SINGLE_Ideas' => 'רעיון',
	'LBL_IDEAS_INFORMATION' => 'מידע בסיסי',
	'LBL_SUBJECT' => 'נושא',
	'LBL_STATUS' => 'סטטוס',
	'Description' => 'תיאור בסיסי',
	'LBL_EXTENT_DESCRIPTION' => 'תיאור מפורט',
	'Attention' => 'תגובות',
	'LBL_NO' => 'מספר',
	'Draft' => 'טיוטה',
	'Proposition' => 'הצעה',
];
$jsLanguageStrings = [
];